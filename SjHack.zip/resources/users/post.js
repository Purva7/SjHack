console.log('hi login post');
if (me) {
    this.creatorId = me.id;
    this.creatorName = me.name;
}