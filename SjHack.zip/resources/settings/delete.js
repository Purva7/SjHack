if(this.active){
    cancel("Setting is still active", 500);
}