dpd.servicescategory.get({id: this.category}).then(function(category){
    this.relatedCategory = category;
});