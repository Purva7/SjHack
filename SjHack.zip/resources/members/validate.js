if(!me.admin && !me.main){
    cancel("You are not authorized to do that", 401);
}