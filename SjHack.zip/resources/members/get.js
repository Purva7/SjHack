dpd.memberscategory.get({id: this.category}).then(function(category){
    this.fullCategory = category;
});