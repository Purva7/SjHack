if(!me.admin && !me.posts && !me.main){
    cancel("Unauthorized", 401);
}